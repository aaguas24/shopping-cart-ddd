package com.tuempresa.shoppingcart.infraestructure.catalog.persistence.jpa.repository;

import com.tuempresa.shoppingcart.infraestructure.catalog.persistence.jpa.entity.InventarioEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;
import java.util.UUID;
@Repository
public interface InventarioJpaRepository extends JpaRepository<InventarioEntity, UUID> {
    Optional<InventarioEntity>  findByProductoId(UUID idProducto);
}
